from setuptools import setup

setup(
    name='InsertGen',
    version='1.1',
    packages=[''],
    url='',
    license='',
    author='EliottRuster',
    author_email='EliottRuster@gmail.com',
    description='A way to do easier'
)
